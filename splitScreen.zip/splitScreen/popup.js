let selectedRatio = { left: 50, right: 50 };

function createTabEntry(tab) {
  createTabInColumn(tab, 'left');
  createTabInColumn(tab, 'right');
}

function createTabInColumn(tab, side) {
  const container = document.getElementById(side + 'Tabs');
  const otherSide = side === 'left' ? 'right' : 'left';

  const wrapper = document.createElement('div');
  wrapper.className = 'tab-entry';
  wrapper.id = `${side}-tab-${tab.id}`;
  wrapper.style.border = '1px solid transparent';
  wrapper.style.borderRadius = '6px';
  wrapper.style.padding = '4px';

  const label = document.createElement('label');

  const input = document.createElement('input');
  input.type = 'checkbox';
  input.value = tab.id;

  input.addEventListener('change', () => {
    // Desmarcar todas las del mismo lado
    document.querySelectorAll(`#${side}Tabs input[type="checkbox"]`).forEach(cb => {
      if (cb !== input) cb.checked = false;
    });

    // Desmarcar del otro lado si estaba seleccionada
    const otherCheckbox = document.querySelector(`#${otherSide}-tab-${tab.id} input`);
    if (input.checked && otherCheckbox) otherCheckbox.checked = false;

    // Visual feedback
    document.querySelectorAll(`#${side}Tabs .tab-entry`).forEach(e => {
      e.style.border = '1px solid transparent';
      e.style.backgroundColor = 'transparent';
    });

    if (input.checked) {
      wrapper.style.border = `2px solid var(--bar-${side})`;
      wrapper.style.backgroundColor =
        side === 'left'
          ? 'rgba(109, 195, 141, 0.2)'
          : 'rgba(128, 191, 255, 0.2)';
    }
  });

  const icon = document.createElement('img');
  icon.src = tab.favIconUrl || '';
  icon.width = 16;
  icon.height = 16;

  const title = document.createElement('span');
  title.textContent = tab.title || tab.url;
  title.style.whiteSpace = 'nowrap';
  title.style.overflow = 'hidden';
  title.style.textOverflow = 'ellipsis';
  title.style.flex = 1;

  label.appendChild(input);
  label.appendChild(icon);
  label.appendChild(title);
  wrapper.appendChild(label);
  container.appendChild(wrapper);
}

document.addEventListener('DOMContentLoaded', async () => {
  const tabs = await chrome.tabs.query({ currentWindow: true });
  tabs.forEach(createTabEntry);

  document.querySelectorAll('.bar').forEach(bar => {
    bar.addEventListener('click', () => {
      document.querySelectorAll('.bar').forEach(b => b.classList.remove('selected'));
      bar.classList.add('selected');
      selectedRatio = {
        left: parseInt(bar.dataset.left),
        right: parseInt(bar.dataset.right)
      };
    });
  });

  document.getElementById('split').addEventListener('click', async () => {
    const screenWidth = screen.availWidth;
    const screenHeight = screen.availHeight;
    const leftWidth = Math.floor(screenWidth * selectedRatio.left / 100);
    const rightWidth = screenWidth - leftWidth;

    const leftTabId = document.querySelector('#leftTabs input:checked')?.value;
    const rightTabId = document.querySelector('#rightTabs input:checked')?.value;

    if (leftTabId) {
      const leftWin = await chrome.windows.create({
        url: 'about:blank',
        left: 0,
        top: 0,
        width: leftWidth,
        height: screenHeight,
        focused: true
      });
      await chrome.tabs.move(parseInt(leftTabId), { windowId: leftWin.id, index: -1 });
      const [blank] = await chrome.tabs.query({ windowId: leftWin.id });
      chrome.tabs.remove(blank.id);
    }

    if (rightTabId) {
      const rightWin = await chrome.windows.create({
        url: 'about:blank',
        left: leftWidth,
        top: 0,
        width: rightWidth,
        height: screenHeight,
        focused: false
      });
      await chrome.tabs.move(parseInt(rightTabId), { windowId: rightWin.id, index: -1 });
      const [blank] = await chrome.tabs.query({ windowId: rightWin.id });
      chrome.tabs.remove(blank.id);
    }
  });
});
